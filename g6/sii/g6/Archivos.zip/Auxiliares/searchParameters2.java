package es.uma.g6.backing.Auxiliares;

public class searchParameters2 {

	private String status;
	
	private String productNumber;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getProductNumber() {
		return productNumber;
	}

	public void setProductNumber(String productNumber) {
		this.productNumber = productNumber;
	}
	
	
	
	
	
	
	
}
