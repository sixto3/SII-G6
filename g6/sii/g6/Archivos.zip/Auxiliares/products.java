package es.uma.g6.backing.Auxiliares;

public class products {
	
	
	private String productNumber;
	
	private String status;
	
	
	private String relationship;


	
	
	public String getProductNumber() {
		return productNumber;
	}


	public void setProductNumber(String productNumber) {
		this.productNumber = productNumber;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getRelationship() {
		return relationship;
	}


	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	
	
	
	
	
	
}
